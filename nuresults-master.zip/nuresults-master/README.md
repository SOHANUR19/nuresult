# nuresult
Honours Results of the National University are seen on this website quickly and easily.
# Demo
https://ashrafulsarkar.github.io/nuresults
# License
Copyright (c) 2020 Ashraful Sarkar <br>
Licensed under the MIT license.
